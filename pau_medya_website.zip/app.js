// PAÜ Medya - Interactive Web Application Script

document.addEventListener('DOMContentLoaded', () => {
  // 1. Navbar Scroll Effect
  const navbar = document.querySelector('.navbar');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // Mobile Menu Toggle
  const mobileToggle = document.getElementById('mobileToggle');
  const navLinks = document.getElementById('navLinks');
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      navLinks.classList.toggle('mobile-open');
    });
  }

  // 2. Events Data & Filter Logic
  const events = [
    {
      id: 1,
      title: 'PAÜ Bahar Şenlikleri & Açılış Konseri',
      category: 'konser',
      categoryName: '🎵 Konser',
      date: '15 Mayıs 2026',
      location: 'Göl Bahçe Etkinlik Alanı',
      countdown: '12 Gün Kaldı',
      link: '#'
    },
    {
      id: 2,
      title: 'Yapay Zeka ve Yazılım Zirvesi 2026',
      category: 'akademik',
      categoryName: '🎓 Akademik',
      date: '20 Nisan 2026',
      location: 'PAÜ Kongre Kültür Merkezi - Salon A',
      countdown: '5 Gün Kaldı',
      link: '#'
    },
    {
      id: 3,
      title: 'Fakülteler Arası Halı Saha Turnuvası',
      category: 'spor',
      categoryName: '⚽ Spor',
      date: '25 Nisan 2026',
      location: 'PAÜ Spor Kompleksi Sahaları',
      countdown: '10 Gün Kaldı',
      link: '#'
    },
    {
      id: 4,
      title: 'PAÜ Tiyatro Kulübü Sahnesi: "Kampüs Halleri"',
      category: 'kulup',
      categoryName: '🎭 Kulüp',
      date: '18 Nisan 2026',
      location: 'Hasan Kasapoğlu Kültür Merkezi',
      countdown: '3 Gün Kaldı',
      link: '#'
    },
    {
      id: 5,
      title: 'Denizli Doğa Yürüyüşü & Teleferik Gezisi',
      category: 'kulup',
      categoryName: '🌲 Kulüp',
      date: '28 Nisan 2026',
      location: 'Bağbaşı Yaylası',
      countdown: '13 Gün Kaldı',
      link: '#'
    },
    {
      id: 6,
      title: 'Girişimcilik ve Kariyer Günleri',
      category: 'akademik',
      categoryName: '🎓 Akademik',
      date: '2 Mayıs 2026',
      location: 'İİBF Konferans Salonu',
      countdown: '17 Gün Kaldı',
      link: '#'
    }
  ];

  const eventsGrid = document.getElementById('eventsGrid');
  const eventFilters = document.querySelectorAll('.event-filter');

  function renderEvents(filterCategory = 'all') {
    if (!eventsGrid) return;
    eventsGrid.innerHTML = '';

    const filtered = filterCategory === 'all' 
      ? events 
      : events.filter(e => e.category === filterCategory);

    filtered.forEach(event => {
      const card = document.createElement('div');
      card.className = 'event-card glass glass-hover';
      card.innerHTML = `
        <span class="event-category-tag">${event.categoryName}</span>
        <div class="event-date-box">
          <i class="far fa-calendar-alt"></i> ${event.date}
        </div>
        <h3 class="event-title">${event.title}</h3>
        <div class="event-location">
          <i class="fas fa-map-marker-alt"></i> ${event.location}
        </div>
        <div class="event-footer">
          <div class="countdown-timer">
            <i class="far fa-clock"></i> ${event.countdown}
          </div>
          <button class="btn-event-join" onclick="showToast('Etkinlik takviminize eklendi! 🎉')">Takvime Ekle</button>
        </div>
      `;
      eventsGrid.appendChild(card);
    });
  }

  renderEvents();

  eventFilters.forEach(btn => {
    btn.addEventListener('click', () => {
      eventFilters.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-filter');
      renderEvents(cat);
    });
  });

  // 3. Humor / Meme Post Like Logic
  window.toggleLike = function(btn) {
    const countSpan = btn.querySelector('.like-count');
    let count = parseInt(countSpan.textContent);
    
    if (btn.classList.contains('liked')) {
      btn.classList.remove('liked');
      count--;
      btn.querySelector('i').className = 'far fa-heart';
    } else {
      btn.classList.add('liked');
      count++;
      btn.querySelector('i').className = 'fas fa-heart';
      showToast('Gönderiyi beğendiniz! ❤️');
    }
    countSpan.textContent = count;
  };

  // 4. Cafeteria Menu Data & Switcher
  const menuData = {
    pazartesi: {
      soup: 'Mercimek Çorbası',
      main: 'İzmir Köfte & Pirinç Pilavı',
      side: 'Mevsim Salatası',
      dessert: 'Kemalpaşa Tatlısı',
      calories: '890 kcal'
    },
    sali: {
      soup: 'Ezogelin Çorbası',
      main: 'Tavuk Sote & Bulgur Pilavı',
      side: 'Cacık',
      dessert: 'Meyve (Elma/Muz)',
      calories: '820 kcal'
    },
    carsamba: {
      soup: 'Yayla Çorbası',
      main: 'Kuru Fasulye & Şehriyeli Pilav',
      side: 'Turşu',
      dessert: 'Sütlaç',
      calories: '910 kcal'
    },
    persembe: {
      soup: 'Domates Çorbası',
      main: 'Fırın Tavuk & Patates Püresi',
      side: 'Akdeniz Salatası',
      dessert: 'İrmik Helvası',
      calories: '850 kcal'
    },
    cuma: {
      soup: 'Tarhana Çorbası',
      main: 'Tas Kebabı & Makarna',
      side: 'Komposto',
      dessert: 'Baklava',
      calories: '950 kcal'
    }
  };

  const dayBtns = document.querySelectorAll('.day-btn');
  const foodSoup = document.getElementById('foodSoup');
  const foodMain = document.getElementById('foodMain');
  const foodSide = document.getElementById('foodSide');
  const foodDessert = document.getElementById('foodDessert');
  const totalCal = document.getElementById('totalCal');

  function updateMenu(day) {
    const m = menuData[day];
    if (!m) return;
    if (foodSoup) foodSoup.textContent = m.soup;
    if (foodMain) foodMain.textContent = m.main;
    if (foodSide) foodSide.textContent = m.side;
    if (foodDessert) foodDessert.textContent = m.dessert;
    if (totalCal) totalCal.textContent = m.calories;
  }

  dayBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      dayBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const day = btn.getAttribute('data-day');
      updateMenu(day);
    });
  });

  // 5. Campus Guide Tab Switcher
  const guideBtns = document.querySelectorAll('.guide-nav-btn');
  const guideTabs = document.querySelectorAll('.guide-tab-content');

  guideBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      guideBtns.forEach(b => b.classList.remove('active'));
      guideTabs.forEach(t => t.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
    });
  });

  // 6. Confession / Message Modal Logic
  const openConfessModalBtn = document.getElementById('openConfessModal');
  const closeConfessModalBtn = document.getElementById('closeConfessModal');
  const confessModal = document.getElementById('confessModal');
  const confessForm = document.getElementById('confessForm');

  if (openConfessModalBtn && confessModal) {
    openConfessModalBtn.addEventListener('click', (e) => {
      e.preventDefault();
      confessModal.classList.add('active');
    });
  }

  if (closeConfessModalBtn && confessModal) {
    closeConfessModalBtn.addEventListener('click', () => {
      confessModal.classList.remove('active');
    });
  }

  if (confessForm) {
    confessForm.addEventListener('submit', (e) => {
      e.preventDefault();
      confessModal.classList.remove('active');
      confessForm.reset();
      showToast('İtirafınız PAÜ Medya ekibine iletildi! 🎉');
    });
  }

  // 7. Hosting Info Modal Logic
  const openHostingModalBtn = document.getElementById('openHostingModal');
  const closeHostingModalBtn = document.getElementById('closeHostingModal');
  const hostingModal = document.getElementById('hostingModal');

  if (openHostingModalBtn && hostingModal) {
    openHostingModalBtn.addEventListener('click', (e) => {
      e.preventDefault();
      hostingModal.classList.add('active');
    });
  }
  if (closeHostingModalBtn && hostingModal) {
    closeHostingModalBtn.addEventListener('click', () => {
      hostingModal.classList.remove('active');
    });
  }

  // Close modals on clicking overlay
  window.addEventListener('click', (e) => {
    if (e.target === confessModal) confessModal.classList.remove('active');
    if (e.target === hostingModal) hostingModal.classList.remove('active');
  });

  // 8. Toast Helper
  window.showToast = function(msg) {
    let toast = document.getElementById('toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast';
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.innerHTML = `<i class="fas fa-check-circle" style="color: var(--primary);"></i> ${msg}`;
    toast.classList.add('show');
    
    setTimeout(() => {
      toast.classList.remove('show');
    }, 3500);
  };

  // 9. Canlı Instagram Veri Çekme, Yönetici Paneli & LocalStorage Sync
  const username = 'pau.medya';
  const followerEl = document.getElementById('followerCount');
  const followingEl = document.getElementById('followingCount');
  const postEl = document.getElementById('postCount');
  const syncStatusEl = document.getElementById('liveSyncStatus');

  const openAdminModalBtn = document.getElementById('openAdminModal');
  const closeAdminModalBtn = document.getElementById('closeAdminModal');
  const adminModal = document.getElementById('adminModal');
  const adminStatsForm = document.getElementById('adminStatsForm');
  const inputPost = document.getElementById('inputPost');
  const inputFollower = document.getElementById('inputFollower');
  const inputFollowing = document.getElementById('inputFollowing');
  const checkAutoGrowth = document.getElementById('checkAutoGrowth');

  // Load saved state from LocalStorage if available
  let savedStats = JSON.parse(localStorage.getItem('pau_medya_stats')) || {
    posts: '0',
    followers: '16',
    following: '9',
    autoGrowth: true
  };

  function applyStats(posts, followers, following) {
    if (postEl) updateCounterAnimated(postEl, posts);
    if (followerEl) updateCounterAnimated(followerEl, followers);
    if (followingEl) updateCounterAnimated(followingEl, following);
  }

  // Initialize display
  applyStats(savedStats.posts, savedStats.followers, savedStats.following);

  if (openAdminModalBtn && adminModal) {
    openAdminModalBtn.addEventListener('click', () => {
      if (inputPost) inputPost.value = savedStats.posts;
      if (inputFollower) inputFollower.value = savedStats.followers;
      if (inputFollowing) inputFollowing.value = savedStats.following;
      if (checkAutoGrowth) checkAutoGrowth.checked = savedStats.autoGrowth;
      adminModal.classList.add('active');
    });
  }

  if (closeAdminModalBtn && adminModal) {
    closeAdminModalBtn.addEventListener('click', () => {
      adminModal.classList.remove('active');
    });
  }

  if (adminStatsForm) {
    adminStatsForm.addEventListener('submit', (e) => {
      e.preventDefault();
      savedStats = {
        posts: inputPost.value || '0',
        followers: inputFollower.value || '16',
        following: inputFollowing.value || '9',
        autoGrowth: checkAutoGrowth.checked
      };
      localStorage.setItem('pau_medya_stats', JSON.stringify(savedStats));
      applyStats(savedStats.posts, savedStats.followers, savedStats.following);
      adminModal.classList.remove('active');
      showToast('Canlı verileriniz başarıyla güncellendi! 🎉');
    });
  }

  // Live Auto-Growth Simulation (Adds +1 student follower periodically if enabled)
  setInterval(() => {
    if (savedStats.autoGrowth) {
      let currentFol = parseInt(savedStats.followers) || 16;
      currentFol += Math.floor(Math.random() * 2) + 1; // +1 or +2 new student follower
      savedStats.followers = currentFol.toString();
      localStorage.setItem('pau_medya_stats', JSON.stringify(savedStats));
      if (followerEl) updateCounterAnimated(followerEl, savedStats.followers);
      if (syncStatusEl) {
        syncStatusEl.innerHTML = `<i class="fas fa-satellite-dish fa-pulse" style="color: var(--success);"></i> Canlı Öğrenci Senkronize (${new Date().toLocaleTimeString('tr-TR')})`;
      }
    }
  }, 12000);

  // Background fetch from serverless API endpoints if live
  async function fetchLiveInstagramStats() {
    const serverlessEndpoints = ['/api/instagram', '/.netlify/functions/instagram'];

    for (let endpoint of serverlessEndpoints) {
      try {
        const apiRes = await fetch(endpoint, { cache: 'no-cache' });
        if (apiRes.ok) {
          const data = await apiRes.json();
          if (data && data.success && data.followers !== undefined && data.followers !== '16') {
            savedStats.followers = data.followers;
            savedStats.following = data.following || savedStats.following;
            savedStats.posts = data.posts || savedStats.posts;
            localStorage.setItem('pau_medya_stats', JSON.stringify(savedStats));
            applyStats(savedStats.posts, savedStats.followers, savedStats.following);

            if (syncStatusEl) {
              syncStatusEl.innerHTML = `<i class="fas fa-satellite-dish fa-pulse" style="color: var(--success);"></i> Canlı Sunucu Senkronize (${new Date().toLocaleTimeString('tr-TR')})`;
            }
            return;
          }
        }
      } catch (apiErr) {
        // Continue
      }
    }
  }

  function updateCounterAnimated(element, newValue) {
    const currentVal = element.textContent.trim();
    if (currentVal !== newValue.toString()) {
      element.style.transition = 'all 0.4s ease';
      element.style.transform = 'scale(1.3)';
      element.style.color = 'var(--primary)';
      element.textContent = newValue;

      setTimeout(() => {
        element.style.transform = 'scale(1)';
        element.style.color = '#fff';
      }, 500);
    }
  }

  // Run fetch background check
  fetchLiveInstagramStats();
  setInterval(fetchLiveInstagramStats, 20000);
});
